package viewmodel;

import javax.servlet.http.HttpServletRequest;

public class CartViewModel extends BaseViewModel{
    public CartViewModel (HttpServletRequest request) {
        super(request);
    }
}